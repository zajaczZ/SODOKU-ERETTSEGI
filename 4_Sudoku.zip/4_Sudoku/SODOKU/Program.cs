﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SODOKU
{
    internal class Program
    {
        static List<List<int>> konnyu = new List<List<int>>();
        static List<List<int>> kozepes = new List<List<int>>();
        static List<List<int>> nehez= new List<List<int>>();
        static void beolvas()
        {
            StreamReader sr = new StreamReader("konnyu.txt");
            while (!sr.EndOfStream)
            {
                List<int> sor = Array.ConvertAll(sr.ReadLine().Split(' '), elem => Convert.ToInt32(elem)).ToList();
                konnyu.Add(sor);
            }
            sr.Close();
        }
        static void beolvas2()
        {
            StreamReader sr = new StreamReader("kozepes.txt");
            while (!sr.EndOfStream)
            {
                List<int> sor = Array.ConvertAll(sr.ReadLine().Split(' '), elem => Convert.ToInt32(elem)).ToList();
                kozepes.Add(sor);
            }
            sr.Close();
        }
        static void beolvas3()
        {
            StreamReader sr = new StreamReader("nehez.txt");
            while (!sr.EndOfStream)
            {
                List<int> sor = Array.ConvertAll(sr.ReadLine().Split(' '), elem => Convert.ToInt32(elem)).ToList();
                nehez.Add(sor);
            }
            sr.Close();
        }
        static void kiir()
        {
            foreach (var sor  in konnyu)
            {
                foreach (var elem  in sor)
                {
                    Console.Write(elem);

                }
                Console.WriteLine();

            }
                       
        }
        static void f3()
        {
            Console.WriteLine("3.feladat");
            Console.WriteLine("Sor:");
            int sor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Oszlop:");
            int oszlop = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < konnyu.Count(); i++)
            {
                for (int j = 0; j < konnyu[i].Count(); j++)
                {
                    if (konnyu[i][i]>0)
                    {
                        Console.WriteLine($"Az adott helyen szereplő szám: {konnyu[i][j]}");
                        return;

                    }
                    else if (konnyu[i][j] == 0)
                    {
                        Console.WriteLine("Az adott helyen még nem töltötték ki!");
                        return;

                    }
                }
                    if (konnyu[i].Count()-1==9)
                    {
                        Console.WriteLine($"A hely a(z){konnyu[i]} résztáblához tartozik.");

                    }

            }

        }
        static void f4()
        {
            int darabNull = 0;
            int darabNemNull = 0;
            int osszDarab = 0;
            for (int i = 0; i < konnyu.Count(); i++)
            {
                for (int j = 0; j < konnyu[i].Count(); j++)
                {
                    if (konnyu[i][j]==0)
                    {
                        darabNull++;

                    }
                    else
                    {
                        darabNemNull++;
                    }

                }
            }
            for (int i = 0; i < konnyu.Count(); i++)
            {
                for (int j = 0; j < konnyu[i].Count(); j++)
                {
                    if (konnyu[i][j]>-1 && konnyu[i].Count()==9)
                    {
                        osszDarab++;

                    }

                }

            }
            Console.WriteLine($"Az üres helyek aránya: {Math.Round(((double)darabNull/osszDarab)*100,1)}%");
            
        }

        static void Main(string[] args)
        {
            beolvas();
            beolvas2();
            beolvas3();
            //kiir();
            //f3();
            f4();


            Console.ReadKey();
        }
    }
}
